import React from 'react'

const Jobs = ({result}) => {
  return (
    <div className=''>{result}
    </div>
  )
}

export default Jobs