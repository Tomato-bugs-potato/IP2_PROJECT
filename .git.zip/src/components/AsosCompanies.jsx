import React from 'react'

const AsosCompanies = () => {
  return (
    <div>AsosCompanies</div>
  )
}

export default AsosCompanies