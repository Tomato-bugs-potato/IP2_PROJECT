import React from 'react'

const WebSignup = () => {
  return (
    <div>WebSignup</div>
  )
}

export default WebSignup